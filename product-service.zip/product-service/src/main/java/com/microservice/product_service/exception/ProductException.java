package com.microservice.product_service.exception;

public class ProductException extends RuntimeException {
	public ProductException(String message) {
		super(message);
	}
}